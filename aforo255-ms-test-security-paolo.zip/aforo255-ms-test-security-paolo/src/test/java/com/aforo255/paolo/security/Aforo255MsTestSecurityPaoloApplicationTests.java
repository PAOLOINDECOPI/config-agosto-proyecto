package com.aforo255.paolo.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aforo255MsTestSecurityPaoloApplicationTests {

	@Test
	void contextLoads() {
	}

}
