INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) VALUES ('andres','$2a$10$Yqyq5Inn7poTju/.OYkQo.gpEEiGKb/JIKFhN2sqzLyWYlkYf9uIK',1, 'dockerStywar', 'vargas','Stywar.vargas@aforo255.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) VALUES ('admin','$2a$10$eTdBsbgVLHYTiD6Wewu6.uBFz1lR43emwCI12RN4AXC3vhqHJSjIm',1, 'Franco', 'chino','Franco.chino@aforo255.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) VALUES ('stywar','$2a$10$T9pC7k/987JKQJ299V0dWOgPlRfWKad/vuj.xT2XqbcMIEFj2tNZm',1, 'Stywar', 'vargas','stywar1.vargas@aforo255.com');
INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1, 1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2, 2);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2, 1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (3, 1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (3, 2);