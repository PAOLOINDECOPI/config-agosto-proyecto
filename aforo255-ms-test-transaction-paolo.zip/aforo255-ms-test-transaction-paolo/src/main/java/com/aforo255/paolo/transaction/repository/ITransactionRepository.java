package com.aforo255.paolo.transaction.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.aforo255.paolo.transaction.entity.Transaction;

public interface ITransactionRepository extends MongoRepository<Transaction, String>{

	@Query("{invoiceId : ?0}")
	public Iterable<Transaction> findInvoiceId(Integer invoiceId);
}
