package com.aforo255.paolo.transaction.service;

import com.aforo255.paolo.transaction.entity.Transaction;

public interface ITransactionService {

	public Transaction save (Transaction transaction);
	public Iterable<Transaction> findByInvoiceId(Integer invoiceId);
	public Iterable<Transaction> findAll();
}
