package com.aforo255.paolo.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aforo255MsTestTransactionPaoloApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aforo255MsTestTransactionPaoloApplication.class, args);
	}

}
