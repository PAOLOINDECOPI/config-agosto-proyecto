package com.aforo255.paolo.transaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aforo255MsTestTransactionPaoloApplicationTests {

	@Test
	void contextLoads() {
	}

}
