package com.aforo255.paolo.invoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aforo255MsTestInvoicePaoloApplicationTests {

	@Test
	void contextLoads() {
	}

}
