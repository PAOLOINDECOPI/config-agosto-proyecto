package com.aforo255.paolo.invoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aforo255MsTestInvoicePaoloApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aforo255MsTestInvoicePaoloApplication.class, args);
	}

}
