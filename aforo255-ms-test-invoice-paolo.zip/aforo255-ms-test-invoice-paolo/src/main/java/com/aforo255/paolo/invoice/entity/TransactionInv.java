package com.aforo255.paolo.invoice.entity;

import java.io.Serializable;

public class TransactionInv implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer operationId;
	private double amount;
	private String datetime;
	private Integer invoiceId;
	public Integer getOperationId() {
		return operationId;
	}
	public void setOperationId(Integer operationId) {
		this.operationId = operationId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public Integer getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(Integer invoiceId) {
		this.invoiceId = invoiceId;
	}
}
