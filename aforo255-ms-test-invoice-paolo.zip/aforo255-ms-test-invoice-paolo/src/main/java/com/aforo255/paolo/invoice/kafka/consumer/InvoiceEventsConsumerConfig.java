package com.aforo255.paolo.invoice.kafka.consumer;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;

@Configuration
@EnableKafka
public class InvoiceEventsConsumerConfig {

}
