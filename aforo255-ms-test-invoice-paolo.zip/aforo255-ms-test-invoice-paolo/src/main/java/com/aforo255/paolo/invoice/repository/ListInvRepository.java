package com.aforo255.paolo.invoice.repository;

import org.springframework.data.repository.CrudRepository;

import com.aforo255.paolo.invoice.entity.ListInv;

public interface ListInvRepository extends CrudRepository <ListInv, Integer> {

}
