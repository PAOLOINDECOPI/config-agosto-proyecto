package com.aforo255.paolo.invoice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.aforo255.paolo.invoice.entity.ListInv;
import com.aforo255.paolo.invoice.service.IListInvService;

@RestController
public class InvoiceController {

	@Autowired
	private IListInvService service;
	
	@GetMapping("listar")
	public List<ListInv> listar(){
		
		return (List<ListInv>)service.findAll();
	}
	
	@GetMapping("/ver/{id}")
	public ListInv detalle (@PathVariable Integer id) {
		ListInv invoice = service.findById(id);
		return invoice;
		
	}
}
