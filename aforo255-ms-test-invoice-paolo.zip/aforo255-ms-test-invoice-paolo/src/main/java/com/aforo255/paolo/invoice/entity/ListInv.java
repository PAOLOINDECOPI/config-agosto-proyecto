package com.aforo255.paolo.invoice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Invoice")
public class ListInv implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, name="id_invoice")
	private Integer IdInvoice;
	@Column(name="amount")
	private double amountInv;
	@Column(name="state")
	private String statusInv;
	public Integer getIdInvoice() {
		return IdInvoice;
	}
	public void setIdInvoice(Integer idInvoice) {
		IdInvoice = idInvoice;
	}
	public double getAmountInv() {
		return amountInv;
	}
	public void setAmountInv(double amountInv) {
		this.amountInv = amountInv;
	}
	public String getStatusInv() {
		return statusInv;
	}
	public void setStatusInv(String statusInv) {
		this.statusInv = statusInv;
	}


}
