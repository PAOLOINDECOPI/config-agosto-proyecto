package com.aforo255.paolo.invoice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aforo255.paolo.invoice.entity.ListInv;
import com.aforo255.paolo.invoice.repository.ListInvRepository;
@Service
public class ListInvService implements IListInvService{

	@Autowired
	ListInvRepository invoicelist;
	
	@Override
	public List<ListInv> findAll() {
		// TODO Auto-generated method stub
		return (List<ListInv>) invoicelist.findAll();
	}

	@Override
	public ListInv findById(Integer id) {
		// TODO Auto-generated method stub
		return invoicelist.findById(id).orElse(null);
	}

	@Override
	public ListInv save(ListInv listinv) {
		// TODO Auto-generated method stub
		return invoicelist.save(listinv);
	}

}
