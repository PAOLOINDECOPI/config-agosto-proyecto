package com.aforo255.paolo.invoice.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aforo255.paolo.invoice.entity.ListInv;
import com.aforo255.paolo.invoice.entity.TransactionInv;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class TransactionInvService {

	@Autowired
	private IListInvService repository;

	@Autowired
	ObjectMapper objectMapper;

	private Logger log = LoggerFactory.getLogger(TransactionInvService.class);

	public void processTransactionInv(ConsumerRecord<Integer, String> consumerdRecord)
			throws JsonMappingException, JsonProcessingException {
		double newAmount = 0;
		ListInv invoicenew = new ListInv();

		TransactionInv event = objectMapper.readValue(consumerdRecord.value(), TransactionInv.class);
		log.info("transactionInv: {}", event.getInvoiceId());
		invoicenew = repository.findById(event.getInvoiceId());
		
		newAmount = invoicenew.getAmountInv() - event.getAmount();
		
		invoicenew.setAmountInv(newAmount);
		log.info("Actualizado Estado de Cuenta" + event.getInvoiceId());
		repository.save(invoicenew);
	}
}
