package com.aforo255.paolo.invoice.service;

import java.util.List;

import com.aforo255.paolo.invoice.entity.ListInv;

public interface IListInvService {
	
	public List<ListInv> findAll();
	public ListInv findById(Integer id);
	public ListInv save (ListInv listinv);
	
}
