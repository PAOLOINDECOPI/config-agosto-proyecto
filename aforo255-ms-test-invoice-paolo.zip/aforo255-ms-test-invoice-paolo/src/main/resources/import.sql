INSERT INTO Invoice(amount,state) VALUES(100,0);
INSERT INTO Invoice(amount,state) VALUES(200,0);
INSERT INTO Invoice(amount,state) VALUES(300,0);
INSERT INTO Invoice(amount,state) VALUES(400,0);
INSERT INTO Invoice(amount,state) VALUES(500,0);
INSERT INTO Invoice(amount,state) VALUES(600,0);