package com.aforo255.paolo.pay.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aforo255.paolo.pay.dao.TransactionDaoPay;
import com.aforo255.paolo.pay.domain.TransactionPay;
@Service
public class TransactionServiceImplPay implements ITransactionServicePay{

	@Autowired
	private TransactionDaoPay transactionDaoPay;
	
	@Override
	@Transactional(readOnly = true)
	public TransactionPay findById(Integer operationId) {
		// TODO Auto-generated method stub
		return transactionDaoPay.findById(operationId).orElse(null);
	}

	@Override
	public TransactionPay save(TransactionPay transactionPay) {
		// TODO Auto-generated method stub
		return transactionDaoPay.save(transactionPay);
	}

}
