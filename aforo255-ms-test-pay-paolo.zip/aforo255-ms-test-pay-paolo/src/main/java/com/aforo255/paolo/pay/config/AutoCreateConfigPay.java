package com.aforo255.paolo.pay.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.kafka.config.TopicBuilder;

public class AutoCreateConfigPay {

public NewTopic payEvent() {
		
		return TopicBuilder.name("transaction-pay")
				.partitions(3)
				.replicas(1)
				.build();
	}
	
}
