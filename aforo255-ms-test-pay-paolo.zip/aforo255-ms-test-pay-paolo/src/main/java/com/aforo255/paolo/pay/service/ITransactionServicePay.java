package com.aforo255.paolo.pay.service;

import com.aforo255.paolo.pay.domain.TransactionPay;

public interface ITransactionServicePay {
	
	public TransactionPay findById (Integer operationId );
	public TransactionPay save (TransactionPay transactionPay);

}
