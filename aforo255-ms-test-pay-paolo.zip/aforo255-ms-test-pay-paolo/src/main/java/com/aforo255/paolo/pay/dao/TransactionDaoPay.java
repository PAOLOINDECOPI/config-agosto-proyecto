package com.aforo255.paolo.pay.dao;

import org.springframework.data.repository.CrudRepository;
import com.aforo255.paolo.pay.domain.TransactionPay;

public interface TransactionDaoPay extends CrudRepository<TransactionPay, Integer>{

}
