package com.aforo255.paolo.pay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aforo255MsTestPayPaoloApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aforo255MsTestPayPaoloApplication.class, args);
	}

}
