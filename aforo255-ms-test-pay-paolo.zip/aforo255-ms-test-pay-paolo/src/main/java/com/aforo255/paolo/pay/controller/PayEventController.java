package com.aforo255.paolo.pay.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aforo255.paolo.pay.domain.TransactionPay;
import com.aforo255.paolo.pay.producer.PayEventProducer;
import com.aforo255.paolo.pay.service.ITransactionServicePay;
import com.fasterxml.jackson.core.JsonProcessingException;
@RestController
public class PayEventController {
	
	private Logger log = LoggerFactory.getLogger(PayEventController.class);
	@Autowired
	PayEventProducer payProducer ;
	@Autowired
	private ITransactionServicePay transactionService;
	
	@PostMapping("/v1/payevent")
	public ResponseEntity<TransactionPay> postPayEvent (@RequestBody TransactionPay transactionPay) throws JsonProcessingException{
		log.info("antes de tranSql");
		TransactionPay tranSql = transactionService.save(transactionPay);
		log.info("despues de tranSql");
		log.info("antes  de sendDepositEvent");
		payProducer.sendPayEvent(tranSql);
		log.info("despues  de sendDepositEvent");
		return  ResponseEntity.status(HttpStatus.CREATED).body(tranSql);				
	}

}
