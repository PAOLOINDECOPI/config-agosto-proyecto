package com.aforo255.paolo.pay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aforo255MsTestPayPaoloApplicationTests {

	@Test
	void contextLoads() {
	}

}
